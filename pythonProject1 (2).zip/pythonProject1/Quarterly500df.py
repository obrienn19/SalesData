import pandas as pd
import numpy as np
discretionarydata=pd.read_csv('Consumerdiscretionary.csv')
discretionarydata1=pd.DataFrame(discretionarydata)
discretionclean=discretionarydata1.drop(columns=['fyearq', 'fqtr', 'indfmt', 'consol', 'popsrc', 'datafmt', 'curcdq', 'datacqtr', 'datafqtr', 'costat','gsubind'])
print(discretionclean)

discretionarydata2=pd.read_csv('Consumerstaples.csv')
discretionarydata3=pd.DataFrame(discretionarydata2)
consumerclean=discretionarydata3.drop(columns=['fyearq', 'fqtr', 'indfmt', 'consol', 'popsrc', 'datafmt', 'curcdq', 'datacqtr', 'datafqtr', 'costat','gsubind'])
print(consumerclean)

discretionarydata4=pd.read_csv('Industrials.csv')
discretionarydata5=pd.DataFrame(discretionarydata4)
industrialsclean=discretionarydata5.drop(columns=['fyearq', 'fqtr', 'indfmt', 'consol', 'popsrc', 'datafmt', 'curcdq', 'datacqtr', 'datafqtr', 'costat','gsubind'])
print(industrialsclean)

discretionarydata6=pd.read_csv('Energy.csv')
discretionarydata7=pd.DataFrame(discretionarydata6)
energyclean=discretionarydata7.drop(columns=['fyearq', 'fqtr', 'indfmt', 'consol', 'popsrc', 'datafmt', 'curcdq', 'datacqtr', 'datafqtr', 'costat','gsubind'])
print(energyclean)

discretionarydata8=pd.read_csv('Healthcare.csv')
discretionarydata9=pd.DataFrame(discretionarydata8)
healthcareclean=discretionarydata9.drop(columns=['fyearq', 'fqtr', 'indfmt', 'consol', 'popsrc', 'datafmt', 'curcdq', 'datacqtr', 'datafqtr', 'costat','gsubind'])
print(healthcareclean)

discretionarydata10=pd.read_csv('Financials.csv')
discretionarydata11=pd.DataFrame(discretionarydata10)
financialsclean=discretionarydata11.drop(columns=['fyearq', 'fqtr', 'indfmt', 'consol', 'popsrc', 'datafmt', 'curcdq', 'datacqtr', 'datafqtr', 'costat','gsubind'])
print(financialsclean)

discretionarydata12=pd.read_csv('Communicationservices.csv')
discretionarydata13=pd.DataFrame(discretionarydata12)
communicationclean=discretionarydata13.drop(columns=['fyearq', 'fqtr', 'indfmt', 'consol', 'popsrc', 'datafmt', 'curcdq', 'datacqtr', 'datafqtr', 'costat','gsubind'])
print(communicationclean)